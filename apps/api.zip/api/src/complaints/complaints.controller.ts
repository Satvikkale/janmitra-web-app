import { Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ComplaintsService } from './complaints.service';
import { AddCommentDto, CreateComplaintDto, ListQueryDto, UpdateStatusDto } from './dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PlatformUserGuard } from '../auth/platform-user.guard';

@UseGuards(JwtAuthGuard, PlatformUserGuard)
@Controller('complaints')
export class ComplaintsController {
  constructor(private readonly svc: ComplaintsService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateComplaintDto) {
    dto.reporterId = req.user.sub;
    return this.svc.create(dto);
  }

  @Get()
  list(@Query() q: ListQueryDto) { return this.svc.list(q); }

  @Get(':id')
  get(@Param('id') id: string) { return this.svc.get(id); }

  @Get(':id/events')
  events(@Param('id') id: string) { return this.svc.eventsFor(id); }

  @Patch(':id/status')
  updateStatus(@Param('id') id: string, @Body() dto: UpdateStatusDto) { return this.svc.updateStatus(id, dto); }

  @Post(':id/comment')
  comment(@Param('id') id: string, @Body() dto: AddCommentDto) { return this.svc.addComment(id, dto); }
}