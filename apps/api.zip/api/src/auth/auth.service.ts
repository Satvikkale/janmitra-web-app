import { Injectable, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { JwtService } from '@nestjs/jwt';
import { Model } from 'mongoose';
import * as argon2 from 'argon2';
import { User } from '../users/user.schema';
import { Org } from '../orgs/orgs.schema';
import { NgoUser } from '../ngo-users/ngo-user.schema';
import { NgoUsersService } from '../ngo-users/ngo-users.service';
import { NgoRegisterDto } from './dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectModel(User.name) private users: Model<User>,
    @InjectModel(Org.name) private orgs: Model<Org>,
    private ngoUsersService: NgoUsersService,
    private jwt: JwtService,
  ) {}

  async register({ name, email, phone, password }: { name: string; email?: string; phone?: string; password: string }) {
    if (!email && !phone) throw new BadRequestException('email or phone required');
    const existing = await this.users.findOne({ $or: [{ email }, { phone }] }).lean();
    if (existing) throw new BadRequestException('User already exists');
    const passwordHash = await argon2.hash(password);
    const u = await this.users.create({ name, email, phone, passwordHash, roles: ['admin'] });
    const tokens = this.signPair(String(u._id), u.roles);
    return { user: this.publicUser(u), ...tokens };
  }

  async registerNgoUser(dto: {
    ngoName: string;
    name: string;
    position: string;
    mobileNo: string;
    password: string;
  }) {
    // Check if NGO user already exists
    const existingUser = await this.ngoUsersService.findByCredentials(dto.ngoName, dto.name);
    if (existingUser) {
      throw new BadRequestException('NGO user already exists with this NGO name and name');
    }

    // Create NGO user
    const ngoUser = await this.ngoUsersService.create(dto);
    const tokens = this.signPair(String(ngoUser.id), ['ngo-user']);

    return {
      user: this.publicNgoUserFromSchema(ngoUser),
      ...tokens,
    };
  }

  async registerNgo(dto: NgoRegisterDto) {
    // Check if NGO already exists with same name or email/phone
    const existingNgo = await this.orgs.findOne({
      $or: [
        { name: dto.ngoInfo.name, type: 'NGO' },
        { contactEmail: dto.ngoInfo.contactEmail },
        { contactPhone: dto.ngoInfo.contactPhone }
      ]
    });
    if (existingNgo) {
      throw new BadRequestException('NGO already registered with this name, email, or phone');
    }

    // Create NGO organization only (no user record)
    const passwordHash = await argon2.hash(dto.password);
    const orgData = {
      name: dto.ngoInfo.name,
      type: 'NGO' as const,
      subtype: dto.ngoInfo.subtype,
      city: dto.ngoInfo.city,
      categories: dto.ngoInfo.categories,
      contactPersonName: dto.name,
      contactEmail: dto.ngoInfo.contactEmail,
      contactPhone: dto.ngoInfo.contactPhone,
      address: dto.ngoInfo.address,
      registrationNumber: dto.ngoInfo.registrationNumber,
      establishedYear: dto.ngoInfo.establishedYear,
      website: dto.ngoInfo.website,
      passwordHash: passwordHash,
      isVerified: false, // NGO needs admin verification
      roles: ['ngo'],
    };
    
    const org = await this.orgs.create(orgData);

    return {
      message: 'NGO registration successful. Please wait for admin verification.',
      org: this.publicOrg(org),
    };
  }

  async login(identifier: string, password: string, userType?: 'admin' | 'ngo' | 'ngo-user', ngoName?: string) {
    if (userType === 'ngo-user') {
      // For NGO user login, find by ngoName and name
      if (!ngoName) {
        throw new BadRequestException('NGO name is required for NGO user login');
      }
      
      const ngoUser = await this.ngoUsersService.findByCredentials(ngoName, identifier);
      if (!ngoUser || !(await this.ngoUsersService.validatePassword(password, ngoUser.password))) {
        throw new UnauthorizedException('Invalid credentials');
      }

      const tokens = this.signPair(String(ngoUser.id), ['ngo-user']);
      return {
        user: this.publicNgoUserFromSchema(ngoUser),
        ...tokens,
      };
    } else if (userType === 'ngo') {
      // For NGO login, find in org collection
      const ngoOrg = await this.orgs.findOne({
        type: 'NGO',
        $or: [
          { contactEmail: identifier },
          { contactPhone: identifier }
        ]
      });

      if (!ngoOrg || !ngoOrg.passwordHash || !(await argon2.verify(ngoOrg.passwordHash, password))) {
        throw new UnauthorizedException('Invalid credentials');
      }

      // Check if NGO is verified
      if (!ngoOrg.isVerified) {
        throw new UnauthorizedException('Your NGO account is not yet verified by admin. Please wait for verification.');
      }

      const tokens = this.signPair(String(ngoOrg._id), ngoOrg.roles || ['ngo']);
      return {
        user: this.publicNgoUser(ngoOrg),
        org: this.publicOrg(ngoOrg),
        ...tokens,
      };
    } else {
      // For admin login, search in users collection
      const user = await this.users.findOne({
        $or: [{ email: identifier }, { phone: identifier }],
        roles: { $ne: 'ngo' }, // Exclude NGO users from admin login
      });

      if (!user || !user.passwordHash || !(await argon2.verify(user.passwordHash, password))) {
        throw new UnauthorizedException('Invalid credentials');
      }

      const tokens = this.signPair(String(user._id), user.roles);
      return { user: this.publicUser(user), ...tokens };
    }
  }

  async refresh(refreshToken: string) {
    try {
      const payload = await this.jwt.verifyAsync(refreshToken, { secret: process.env.JWT_SECRET });
      if (payload.typ !== 'refresh') throw new UnauthorizedException();
      const tokens = this.signPair(payload.sub, payload.roles || []);
      return tokens;
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }
  }

  async getAvailableNgos() {
    return this.ngoUsersService.getAvailableNgos();
  }

  private signPair(sub: string, roles: string[]) {
    const accessToken = this.jwt.sign(
      { sub, roles, typ: 'access' },
      { expiresIn: process.env.ACCESS_TOKEN_TTL || '15m' },
    );
    const refreshToken = this.jwt.sign(
      { sub, roles, typ: 'refresh' },
      { expiresIn: process.env.REFRESH_TOKEN_TTL || '7d' },
    );
    return { accessToken, refreshToken };
  }

  private publicUser(u: any) {
    return { id: String(u._id), name: u.name, email: u.email, phone: u.phone, roles: u.roles };
  }

  private publicNgoUser(org: any) {
    return {
      id: String(org._id),
      name: org.contactPersonName || org.name,
      email: org.contactEmail,
      phone: org.contactPhone,
      roles: org.roles || ['ngo'],
      isVerified: org.isVerified || false,
      userType: 'ngo'
    };
  }

  private publicNgoUserFromSchema(ngoUser: any) {
    return {
      id: String(ngoUser.id || ngoUser._id),
      name: ngoUser.name,
      ngoName: ngoUser.ngoName,
      position: ngoUser.position,
      mobileNo: ngoUser.mobileNo,
      roles: ['ngo-user'],
      userType: 'ngo-user'
    };
  }

  private publicOrg(org: any) {
    return {
      id: String(org._id),
      name: org.name,
      type: org.type,
      subtype: org.subtype,
      city: org.city,
      categories: org.categories,
      contactPersonName: org.contactPersonName,
      contactEmail: org.contactEmail,
      contactPhone: org.contactPhone,
      address: org.address,
      registrationNumber: org.registrationNumber,
      establishedYear: org.establishedYear,
      website: org.website,
      isVerified: org.isVerified,
    };
  }
}