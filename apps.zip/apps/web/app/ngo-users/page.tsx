'use client';
import React, { useEffect, useState, useRef } from 'react';
import { apiFetch } from '@/lib/auth';
import { useAuth } from '@/contexts/AuthContext';

interface NgoUserData {
  _id: string;
  ngoName: string;
  name: string;
  position: string;
  mobileNo: string;
  userType: string;
  isActive: boolean;
  profilePhoto: string;
  createdAt: string;
  updatedAt: string;
}

export default function NGOUsers() {
  const [userData, setUserData] = useState<NgoUserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    mobileNo: '',
    isActive: true,
    profilePhoto: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { isLoggedIn } = useAuth();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        const data = await apiFetch('/ngo-users/me');
        setUserData(data);
        setEditForm({
          name: data.name,
          mobileNo: data.mobileNo,
          isActive: data.isActive,
          profilePhoto: data.profilePhoto || ''
        });
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch user data');
      } finally {
        setLoading(false);
      }
    };

    if (isLoggedIn) {
      fetchUserData();
    } else {
      setLoading(false);
    }
  }, [isLoggedIn]);

  const handleEditClick = () => {
    if (userData) {
      setEditForm({
        name: userData.name,
        mobileNo: userData.mobileNo,
        isActive: userData.isActive,
        profilePhoto: userData.profilePhoto || ''
      });
      setIsEditing(true);
    }
  };

  const handleSaveProfile = async () => {
    try {
      setSaving(true);
      const updatedData = await apiFetch('/ngo-users/me', {
        method: 'PATCH',
        body: JSON.stringify(editForm)
      });
      setUserData(updatedData);
      setIsEditing(false);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const compressImage = (file: File, maxWidth: number = 300, quality: number = 0.7): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          if (width > maxWidth) {
            height = (height * maxWidth) / width;
            width = maxWidth;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedBase64);
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressedImage = await compressImage(file);
        setEditForm(prev => ({ ...prev, profilePhoto: compressedImage }));
      } catch (err) {
        console.error('Error compressing image:', err);
        setError('Failed to process image');
      }
    }
  };

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">NGO Users Dashboard</h1>
        <p className="text-red-600 text-lg">Please log in to view your dashboard.</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">NGO Users Dashboard</h1>
        <p className="text-red-600 text-lg">Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-blue-100">
      <div className="flex justify-between items-center mb-6 pb-3 border-b border-blue-100">
        <h1 className="text-xl font-bold text-blue-900"></h1>
        {userData && (
          <button
            onClick={handleEditClick}
            className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
          >
            Edit Profile
          </button>
        )}
      </div>
      
      {userData && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-100">
            <div className="flex items-center mb-4">
              {userData.profilePhoto ? (
                <img
                  src={userData.profilePhoto}
                  alt={userData.name}
                  className="w-14 h-14 rounded-full object-cover mr-4 border-2 border-blue-300"
                />
              ) : (
                <span className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-full flex items-center justify-center mr-4 text-lg font-bold">
                  {userData.name.charAt(0).toUpperCase()}
                </span>
              )}
              <div>
                <h2 className="text-base font-bold text-blue-900">{userData.name}</h2>
                <p className="text-sm text-indigo-600 font-medium">{userData.position}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-orange-500 shadow-sm">
                <label className="text-xs font-bold text-orange-600 uppercase">Member of </label>
                <p className="text-sm text-gray-800 truncate font-medium">{userData.ngoName} NGO</p>
              </div>
              
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-indigo-500 shadow-sm">
                <label className="text-xs font-bold text-indigo-600 uppercase">Position at {userData.ngoName}</label>
                <p className="text-sm text-gray-800 font-medium">{userData.position}</p>
              </div>
              
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-teal-500 shadow-sm">
                <label className="text-xs font-bold text-teal-600 uppercase">Mobile no.</label>
                <p className="text-sm text-gray-800 font-medium">{userData.mobileNo}</p>
              </div>
              
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-pink-500 shadow-sm">
                <label className="text-xs font-bold text-pink-600 uppercase">Type</label>
                <p className="text-sm text-gray-800 capitalize font-medium">{userData.userType}</p>
              </div>
              
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-gray-500 shadow-sm">
                <label className="text-xs font-bold text-gray-600 uppercase">Status</label>
                <p><span className={`text-xs px-2 py-1 rounded-full font-semibold ${
                  userData.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {userData.isActive ? 'Active' : 'Inactive'}
                </span></p>
              </div>
              
              <div className="bg-white p-3 rounded-lg border-l-3 border-l-blue-500 shadow-sm">
                <label className="text-xs font-bold text-blue-600 uppercase">Since</label>
                <p className="text-sm text-gray-800 font-medium">
                  {new Date(userData.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: '2-digit' })}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-4 rounded-xl">
            <h3 className="text-sm font-bold text-white">Quick Actions</h3>
            <p className="text-xs text-blue-100">Manage assigned complaints from your dashboard.</p>
          </div>
        </div>
      )}

      {isEditing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-lg font-bold text-blue-900 mb-5">Edit Profile</h2>
            
            <div className="flex flex-col items-center mb-5">
              <div className="relative">
                {editForm.profilePhoto ? (
                  <img
                    src={editForm.profilePhoto}
                    alt="Profile"
                    className="w-20 h-20 rounded-full object-cover border-3 border-blue-200"
                  />
                ) : (
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-full flex items-center justify-center text-2xl font-bold">
                    {editForm.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </button>
              </div>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
            </div>

            <div className="mb-4">
              <label className="block text-xs font-bold text-gray-600 mb-1 uppercase">Name</label>
              <input
                type="text"
                value={editForm.name}
                onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="mb-4">
              <label className="block text-xs font-bold text-gray-600 mb-1 uppercase">Mobile</label>
              <input
                type="tel"
                value={editForm.mobileNo}
                onChange={(e) => setEditForm(prev => ({ ...prev, mobileNo: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="mb-5">
              <label className="block text-xs font-bold text-gray-600 mb-1 uppercase">Status</label>
              <div className="flex items-center">
                <button
                  type="button"
                  onClick={() => setEditForm(prev => ({ ...prev, isActive: !prev.isActive }))}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    editForm.isActive ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    editForm.isActive ? 'translate-x-6' : 'translate-x-1'
                  }`} />
                </button>
                <span className={`ml-3 text-sm font-semibold ${editForm.isActive ? 'text-green-600' : 'text-gray-500'}`}>
                  {editForm.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setIsEditing(false)}
                className="flex-1 px-4 py-2 text-sm border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProfile}
                disabled={saving}
                className="flex-1 px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}