import React from 'react'

type Props = {}

export default function NGOAnalytics({}: Props) {
  return (
    <div>NGO Analytics</div>
  )
}