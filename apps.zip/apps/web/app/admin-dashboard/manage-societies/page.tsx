import React from 'react'

type Props = {}

export default function ManageSocieties({}: Props) {
  return (
    <div>Manage Societies</div>
  )
}