'use client';
import React, { useState, useEffect } from 'react';
import { apiFetch } from '@/lib/auth';
import { useAuth } from '@/contexts/AuthContext';

interface NGOData {
    _id: string;
    ngoName: string;
    email: string;
    registrationNumber: string;
    address: string;
    contactPerson: string;
    contactPhone: string;
    description: string;
    isVerified: boolean;
    createdAt: string;
    subtype: string;
    city: string;
    categories: string[];
    establishedYear: string;
    website: string;
}

interface NGOResponse {
    pending: NGOData[];
    verified: NGOData[];
}

export default function ManageNGOsPage() {
    const [ngoData, setNgoData] = useState<NGOResponse>({ pending: [], verified: [] });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<'pending' | 'verified'>('pending');
    const [actionLoading, setActionLoading] = useState<string | null>(null);
    const { isLoggedIn } = useAuth();

    const fetchNGOs = async () => {
        try {
            setLoading(true);
            const data = await apiFetch('/orgs/ngos');
            setNgoData(data);
            setError(null);
        } catch (err: any) {
            console.error('Error fetching NGOs:', err);
            if (err.message.includes('401') || err.message.includes('Unauthorized')) {
                setError('You are not authorized to access this data. Please login as an admin user.');
            } else {
                setError('Failed to fetch NGO data. Please check your permissions and try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isLoggedIn) {
            fetchNGOs();
        }
    }, [isLoggedIn]);

    const handleVerifyNgo = async (ngoId: string) => {
        try {
            setActionLoading(ngoId);
            await apiFetch('/orgs/verify-ngo', {
                method: 'POST',
                body: JSON.stringify({ ngoId })
            });
            await fetchNGOs();
        } catch (err: any) {
            console.error('Error verifying NGO:', err);
            if (err.message.includes('401') || err.message.includes('Unauthorized')) {
                setError('You are not authorized to perform this action. Please login as an admin user.');
            } else {
                setError('Failed to verify NGO. Please try again.');
            }
        } finally {
            setActionLoading(null);
        }
    };

    const handleRejectNgo = async (ngoId: string) => {
        if (!confirm('Are you sure you want to reject this NGO? This action cannot be undone.')) {
            return;
        }
        
        try {
            setActionLoading(ngoId);
            await apiFetch('/orgs/reject-ngo', {
                method: 'POST',
                body: JSON.stringify({ ngoId })
            });
            await fetchNGOs();
        } catch (err: any) {
            console.error('Error rejecting NGO:', err);
            if (err.message.includes('401') || err.message.includes('Unauthorized')) {
                setError('You are not authorized to perform this action. Please login as an admin user.');
            } else {
                setError('Failed to reject NGO. Please try again.');
            }
        } finally {
            setActionLoading(null);
        }
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const NGOTable = ({ ngos, showActions = false }: { ngos: NGOData[], showActions?: boolean }) => (
        <div className="overflow-x-auto bg-white rounded-xl shadow-lg border border-slate-200">
            <div className="space-y-4 p-6">
                {ngos.map((ngo) => (
                    <div key={ngo._id} className="bg-gradient-to-r from-white to-slate-50 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 border border-slate-200 overflow-hidden">
                        <div className="p-6">
                            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                                {/* Main NGO Info */}
                                <div className="flex-1 space-y-4">
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <h3 className="text-xl font-bold text-slate-900 mb-2">{ngo.ngoName}</h3>
                                            <div className="flex items-center gap-3 mb-3">
                                                <span className="bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium border border-purple-200">
                                                    {ngo.subtype}
                                                </span>
                                                <span className="text-slate-600 text-sm font-medium">📍 {ngo.city}</span>
                                                {ngo.establishedYear && (
                                                    <span className="text-slate-600 text-sm">🏛️ Est. {ngo.establishedYear}</span>
                                                )}
                                            </div>
                                        </div>
                                        <span className={`inline-flex items-center px-4 py-2 text-sm font-semibold rounded-full shadow-md ${
                                            ngo.isVerified 
                                                ? 'bg-gradient-to-r from-emerald-500 to-green-500 text-white' 
                                                : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white'
                                        }`}>
                                            {ngo.isVerified ? '✓ Verified' : '⏳ Pending'}
                                        </span>
                                    </div>

                                    {/* Categories */}
                                    {ngo.categories.length > 0 && (
                                        <div className="flex flex-wrap gap-2">
                                            {ngo.categories.map((category, index) => (
                                                <span
                                                    key={index}
                                                    className="bg-gradient-to-r from-blue-50 to-cyan-50 text-blue-700 px-3 py-1 rounded-lg text-sm font-medium border border-blue-200 shadow-sm"
                                                >
                                                    {category}
                                                </span>
                                            ))}
                                        </div>
                                    )}

                                    {/* Description */}
                                    <div className="bg-gradient-to-r from-slate-50 to-gray-50 rounded-xl p-4 border border-slate-200">
                                        <p className="text-slate-700 text-sm leading-relaxed">
                                            {ngo.description || 'No description provided'}
                                        </p>
                                        <p className="text-slate-500 text-sm mt-2">
                                            📍 {ngo.address}
                                        </p>
                                    </div>
                                </div>

                                {/* Contact & Registration Info */}
                                <div className="lg:w-80 space-y-4">
                                    {/* Contact Card */}
                                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-200">
                                        <h4 className="font-semibold text-slate-800 mb-3 flex items-center">
                                            <span className="mr-2">👤</span>
                                            Contact Information
                                        </h4>
                                        <div className="space-y-2 text-sm">
                                            <div className="flex items-center text-slate-700">
                                                <span className="w-4 mr-2">👨‍💼</span>
                                                <span className="font-medium">{ngo.contactPerson}</span>
                                            </div>
                                            <div className="flex items-center text-slate-600">
                                                <span className="w-4 mr-2">📧</span>
                                                <span>{ngo.email}</span>
                                            </div>
                                            <div className="flex items-center text-slate-600">
                                                <span className="w-4 mr-2">📞</span>
                                                <span>{ngo.contactPhone}</span>
                                            </div>
                                            {ngo.website && (
                                                <div className="flex items-center">
                                                    <span className="w-4 mr-2">🌐</span>
                                                    <a 
                                                        href={ngo.website} 
                                                        target="_blank" 
                                                        rel="noopener noreferrer"
                                                        className="text-blue-600 hover:text-blue-800 font-medium transition-colors duration-200 hover:underline"
                                                    >
                                                        Visit Website
                                                    </a>
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {/* Registration Card */}
                                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-200">
                                        <h4 className="font-semibold text-slate-800 mb-3 flex items-center">
                                            <span className="mr-2">📋</span>
                                            Registration Details
                                        </h4>
                                        <div className="space-y-2 text-sm">
                                            <div className="flex items-center text-slate-700">
                                                <span className="w-4 mr-2">🆔</span>
                                                <span className="font-mono">{ngo.registrationNumber || 'N/A'}</span>
                                            </div>
                                            <div className="flex items-center text-slate-600">
                                                <span className="w-4 mr-2">📅</span>
                                                <span>Registered: {formatDate(ngo.createdAt)}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Action Buttons */}
                                    {showActions && (
                                        <div className="flex flex-col gap-3">
                                            <button
                                                onClick={() => handleVerifyNgo(ngo._id)}
                                                disabled={actionLoading === ngo._id}
                                                className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 disabled:from-slate-400 disabled:to-slate-500 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                                            >
                                                {actionLoading === ngo._id ? (
                                                    <>
                                                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                                                        Processing...
                                                    </>
                                                ) : (
                                                    <>
                                                        <span>✓</span>
                                                        Verify NGO
                                                    </>
                                                )}
                                            </button>
                                            <button
                                                onClick={() => handleRejectNgo(ngo._id)}
                                                disabled={actionLoading === ngo._id}
                                                className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 disabled:from-slate-400 disabled:to-slate-500 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                                            >
                                                {actionLoading === ngo._id ? (
                                                    <>
                                                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                                                        Processing...
                                                    </>
                                                ) : (
                                                    <>
                                                        <span>✕</span>
                                                        Reject NGO
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            {ngos.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                    <div className="text-slate-400 text-lg mb-2">📋</div>
                    No NGOs found in this category.
                </div>
            )}
        </div>
    );

    if (!isLoggedIn) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
                <div className="container mx-auto px-4 py-8">
                    <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 text-amber-800 px-6 py-4 rounded-xl shadow-lg">
                        <div className="flex items-center justify-between">
                            <span className="font-medium">Please log in to access the NGO management panel.</span>
                            <a 
                                href="/auth/login" 
                                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-6 py-2 rounded-lg transition-all duration-200 font-medium shadow-md hover:shadow-lg"
                            >
                                Login
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
            <div className="container mx-auto px-4 py-8">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent mb-3">
                        Manage NGOs
                    </h1>
                    <p className="text-slate-600 text-lg">View and manage NGO registrations and verifications</p>
                </div>

                {error && (
                    <div className="mb-6 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 text-red-800 px-6 py-4 rounded-xl shadow-lg">
                        <div className="flex items-start justify-between">
                            <span className="font-medium">{error}</span>
                            <button 
                                onClick={() => setError(null)}
                                className="ml-4 text-red-700 hover:text-red-900 font-semibold transition-colors duration-200"
                            >
                                ✕
                            </button>
                        </div>
                    </div>
                )}

                {/* Statistics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-white overflow-hidden shadow-lg rounded-xl border border-slate-200 hover:shadow-xl transition-all duration-300">
                        <div className="p-6">
                            <div className="flex items-center">
                                <div className="flex-shrink-0">
                                    <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                                        <span className="text-white font-bold text-lg">⏳</span>
                                    </div>
                                </div>
                                <div className="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt className="text-sm font-semibold text-slate-600 truncate">Pending NGOs</dt>
                                        <dd className="text-2xl font-bold text-slate-900">{ngoData.pending.length}</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-lg rounded-xl border border-slate-200 hover:shadow-xl transition-all duration-300">
                        <div className="p-6">
                            <div className="flex items-center">
                                <div className="flex-shrink-0">
                                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-green-500 rounded-xl flex items-center justify-center shadow-lg">
                                        <span className="text-white font-bold text-lg">✓</span>
                                    </div>
                                </div>
                                <div className="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt className="text-sm font-semibold text-slate-600 truncate">Verified NGOs</dt>
                                        <dd className="text-2xl font-bold text-slate-900">{ngoData.verified.length}</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-lg rounded-xl border border-slate-200 hover:shadow-xl transition-all duration-300">
                        <div className="p-6">
                            <div className="flex items-center">
                                <div className="flex-shrink-0">
                                    <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                                        <span className="text-white font-bold text-lg">📊</span>
                                    </div>
                                </div>
                                <div className="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt className="text-sm font-semibold text-slate-600 truncate">Total NGOs</dt>
                                        <dd className="text-2xl font-bold text-slate-900">
                                            {ngoData.pending.length + ngoData.verified.length}
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Tab Navigation */}
                <div className="mb-6">
                    <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-1">
                        <nav className="flex space-x-1">
                            <button
                                onClick={() => setActiveTab('pending')}
                                className={`flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all duration-200 ${
                                    activeTab === 'pending'
                                        ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                                        : 'text-slate-600 hover:text-slate-800 hover:bg-slate-50'
                                }`}
                            >
                                Pending NGOs ({ngoData.pending.length})
                            </button>
                            <button
                                onClick={() => setActiveTab('verified')}
                                className={`flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all duration-200 ${
                                    activeTab === 'verified'
                                        ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                                        : 'text-slate-600 hover:text-slate-800 hover:bg-slate-50'
                                }`}
                            >
                                Verified NGOs ({ngoData.verified.length})
                            </button>
                        </nav>
                    </div>
                </div>

                {/* Refresh Button */}
                <div className="mb-6">
                    <button
                        onClick={fetchNGOs}
                        disabled={loading}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:from-slate-400 disabled:to-slate-500 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl"
                    >
                        {loading ? '🔄 Loading...' : '🔄 Refresh Data'}
                    </button>
                </div>

                {/* NGO Tables */}
                {loading ? (
                    <div className="text-center py-16">
                        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600"></div>
                        <p className="mt-4 text-slate-600 font-medium">Loading NGO data...</p>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {activeTab === 'pending' && (
                            <div>
                                <h2 className="text-2xl font-bold text-slate-800 mb-6">
                                    Pending NGOs ({ngoData.pending.length})
                                </h2>
                                <NGOTable ngos={ngoData.pending} showActions={true} />
                            </div>
                        )}
                        
                        {activeTab === 'verified' && (
                            <div>
                                <h2 className="text-2xl font-bold text-slate-800 mb-6">
                                    Verified NGOs ({ngoData.verified.length})
                                </h2>
                                <NGOTable ngos={ngoData.verified} showActions={false} />
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}