'use client';

import React from 'react';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import {
  Camera,
  Users,
  Bell,
  Shield
} from "lucide-react";
import Image from 'next/image';
import HeroImage from '../../web/assets/images/hero-image.png';
import QRImage from '../../web/assets/images/QR.jpg';

interface Feature {
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface Step {
  number: number;
  title: string;
  description: string;
}


const features: Feature[] = [
  {
    icon: <Camera className="h-12 w-12 text-emerald-500 mx-auto mb-4" />,
    title: "AI-Powered Capture",
    description: "Take a photo of any community issue and let AI automatically categorize and prioritize your complaint.",
  },
  {
    icon: <Users className="h-12 w-12 text-violet-500 mx-auto mb-4" />,
    title: "Community Connect",
    description: "Connect residents, society secretaries, and NGOs on a unified platform for better communication.",
  },
  {
    icon: <Bell className="h-12 w-12 text-amber-500 mx-auto mb-4" />,
    title: "Real-time Notifications",
    description: "Get instant notifications when your complaints are reviewed, updated, or resolved by authorities.",
  },
  {
    icon: <Shield className="h-12 w-12 text-rose-500 mx-auto mb-4" />,
    title: "Secure & Reliable",
    description: "Your data is secure with role-based access control and transparent complaint tracking system.",
  },
];

const steps: Step[] = [
  {
    number: 1,
    title: "Scan QR Code and Download App",
    description: "Scan the QR code and Download the app.",
  },
  {
    number: 2,
    title: "Open App and Register",
    description: "Open the app and register using your name and password",
  },
  {
    number: 3,
    title: "Capture image and Submit Complaint",
    description: "Capture an image of the issue and submit your complaint through the app.",
  },
  {
    number: 4,
    title: "Track Progress",
    description: "Monitor the status of your complaint and receive updates until resolution.",
  },
];


interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const userType = localStorage.getItem('userType');

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => (
  <div className="text-center bg-gradient-to-br from-white to-slate-50 border border-slate-200 shadow-lg rounded-2xl p-8 hover:shadow-xl transition-all duration-300">
    <div>{icon}</div>
    <h3 className="text-xl font-bold mb-3 text-slate-800">{title}</h3>
    <p className="text-slate-600 leading-relaxed">{description}</p>
  </div>
);

interface StepItemProps {
  number: number;
  title: string;
  description: string;
}

const StepItem: React.FC<StepItemProps> = ({ number, title, description }) => (
  <div className="flex items-start">
    <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-full flex items-center justify-center font-bold mr-4 shadow-lg">
      {number}
    </div>
    <div>
      <h3 className="font-bold text-slate-800 text-lg">{title}</h3>
      <p className="text-slate-600 mt-1">{description}</p>
    </div>
  </div>
);

interface CircularProgressProps {
  percentage: number;
  size?: number;
  color?: string;
}

const CircularProgress: React.FC<CircularProgressProps> = ({
  percentage,
  size = 120,
  color = "#10b981"
}) => {
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#e2e8f0"
          strokeWidth="8"
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth="8"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold" style={{ color }}>
          {percentage}%
        </span>
      </div>
    </div>
  );
};

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  subtitle: string;
  color?: 'blue' | 'green' | 'yellow' | 'red';
}

const StatCard: React.FC<StatCardProps> = ({
  icon,
  title,
  value,
  subtitle,
  color = 'blue'
}) => {
  const colorClasses = {
    blue: "bg-gradient-to-br from-blue-50 to-cyan-50 text-blue-600 border-blue-200",
    green: "bg-gradient-to-br from-emerald-50 to-teal-50 text-emerald-600 border-emerald-200",
    yellow: "bg-gradient-to-br from-amber-50 to-yellow-50 text-amber-600 border-amber-200",
    red: "bg-gradient-to-br from-rose-50 to-pink-50 text-rose-600 border-rose-200"
  };

  return (
    <div className={`p-6 rounded-2xl border ${colorClasses[color]} shadow-lg hover:shadow-xl transition-all duration-300`}>
      <div className="flex items-center">
        <div className={`p-3 rounded-xl ${colorClasses[color]} shadow-md`}>
          {icon}
        </div>
        <div className="ml-4">
          <p className="text-sm font-semibold text-slate-600">{title}</p>
          <p className="text-3xl font-bold text-slate-800">{value}</p>
          <p className="text-sm text-slate-500">{subtitle}</p>
        </div>
      </div>
    </div>
  );
};

interface CategoryBarProps {
  category: string;
  count: number;
  percentage: number;
  maxCount: number;
}

const CategoryBar: React.FC<CategoryBarProps> = ({
  category,
  count,
  percentage,
  maxCount
}) => {
  const width = (count / maxCount) * 100;

  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-semibold text-slate-700">{category}</span>
        <span className="text-sm text-slate-500 font-medium">{count} ({percentage}%)</span>
      </div>
      <div className="w-full bg-slate-200 rounded-full h-3">
        <div
          className="bg-gradient-to-r from-violet-500 to-purple-600 h-3 rounded-full transition-all duration-1000 ease-out shadow-sm"
          style={{ width: `${width}%` }}
        ></div>
      </div>
    </div>
  );
};

interface TrendChartProps {
  data: { month: string; complaints: number; resolved: number }[];
}

const TrendChart: React.FC<TrendChartProps> = ({ data }) => {
  const maxValue = Math.max(...data.map(d => Math.max(d.complaints, d.resolved)));

  return (
    <div className="p-4">
      <div className="flex items-end space-x-4 h-32">
        {data.map((item, index) => {
          const complaintsHeight = (item.complaints / maxValue) * 100;
          const resolvedHeight = (item.resolved / maxValue) * 100;

          return (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="flex items-end space-x-1 mb-2 h-20">
                <div
                  className="w-4 bg-gradient-to-t from-violet-500 to-purple-600 rounded-t transition-all duration-1000 ease-out shadow-sm"
                  style={{ height: `${complaintsHeight}%` }}
                  title={`${item.complaints} complaints`}
                ></div>
                <div
                  className="w-4 bg-gradient-to-t from-emerald-500 to-teal-600 rounded-t transition-all duration-1000 ease-out shadow-sm"
                  style={{ height: `${resolvedHeight}%` }}
                  title={`${item.resolved} resolved`}
                ></div>
              </div>
              <span className="text-xs text-slate-600 font-medium">{item.month}</span>
            </div>
          );
        })}
      </div>
      <div className="flex justify-center space-x-4 mt-4 text-xs">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-gradient-to-r from-violet-500 to-purple-600 rounded mr-1"></div>
          <span className="font-medium">Complaints</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-gradient-to-r from-emerald-500 to-teal-600 rounded mr-1"></div>
          <span className="font-medium">Resolved</span>
        </div>
      </div>
    </div>
  );
};

export default function MainPage() {
  const { isLoggedIn } = useAuth();

  const scrollToHowItWorks = (): void => {
    const section = document.getElementById("how-it-works");
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="bg-gradient-to-br from-slate-50 via-white to-blue-50 min-h-screen">
      <div className="mx-auto max-w-screen-xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:items-center md:gap-8 mt-15">
          <div>
            <div className="max-w-lg md:max-w-none">
              <h1 className="text-4xl font-bold text-slate-900 sm:text-5xl leading-tight">
                Welcome to <strong className="bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">JanMirta</strong>
              </h1>

              <p className="mt-6 text-slate-600 text-lg leading-relaxed">
                JanMirta is the central platform where all data processing and workflow control happens.
                The mobile app empowers residents to capture and submit issues, while the web dashboard
                enables organizations to manage and resolve complaints efficiently. Any feature updates
                or changes made on JanMirta automatically reflect across both the app and dashboard —
                keeping your system in sync without extra work.
              </p>

              {!isLoggedIn ? (
                <div className="mt-8 space-x-4">
                  <button
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 px-6 py-3 font-semibold text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
                    onClick={scrollToHowItWorks}
                  >
                    Download App
                  </button>
                  <Link
                    href="/auth/register"
                    className="inline-flex items-center gap-2 rounded-xl border-2 border-violet-600 bg-white px-6 py-3 font-semibold text-violet-600 shadow-lg transition-all hover:bg-violet-50 hover:scale-105"
                  >
                    Get Started
                  </Link>
                  <Link
                    href="/auth/login"
                    className="inline-flex items-center gap-2 rounded-xl border-2 border-slate-300 bg-white px-6 py-3 font-semibold text-slate-700 shadow-lg transition-all hover:bg-slate-50 hover:scale-105"
                  >
                    Sign In
                  </Link>
                </div>
              ) : (
                <div className="mt-8 space-x-4">
                  
                  <button
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 px-6 py-3 font-semibold text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
                    onClick={scrollToHowItWorks}
                  >
                    Download App
                  </button>
                  {userType === 'admin' && (<Link
                    href="/admin-dashboard"
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-3 font-semibold text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
                  >
                    Admin Dashboard
                  </Link>)}
                  {userType === 'ngo' && (<Link
                    href="/ngo-dashboard"
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-3 font-semibold text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
                  >
                    NGO Dashboard
                  </Link>)}
                </div>
              )}
            </div>
          </div>

          <div className="relative">
            <Image
              src={HeroImage}
              className="relative z-10"
              alt="Community engagement through JanMirta"
            />
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20 mt-20">
          {features.map((feature, idx) => (
            <div key={`feature-${idx}`} className="transition-transform transform hover:-translate-y-2 hover:scale-105">
              <FeatureCard {...feature} />
            </div>
          ))}
        </div>

        {/* How It Works Section */}
        <div id="how-it-works" className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-3xl shadow-2xl p-8 md:p-12 mb-20 border border-violet-100">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-8">How It Works</h2>
              <div className="space-y-6">
                {steps.map((step, idx) => (
                  <StepItem key={idx} {...step} />
                ))}
              </div>
            </div>
            <div className="md:pl-30 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-violet-300/30 to-purple-300/30 rounded-2xl blur-2xl"></div>
              <Image
                src={QRImage}
                alt="Smart Community App Interface"
                className="w-full rounded-xl relative z-10"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
